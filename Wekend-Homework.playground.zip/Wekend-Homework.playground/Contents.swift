import UIKit

 public class Hospital {
     var name : String = "Farasan Hospital"
     var hospitalColor : String = "White"
     var idBilding : Int = 75
     
    
//    init(name:String,hospitalColor:String) {
//        self.name = name
//        self.hospitalColor = hospitalColor
//    }
     func sayHai(){
         print("Welcome to \(name)")
     }
     
}
var hospitalJazan = Hospital()
hospitalJazan.name = "Jazan Hospital"
hospitalJazan.hospitalColor = "Black"
hospitalJazan.idBilding = 20
hospitalJazan.sayHai()

var hospitalJeddah = Hospital()
hospitalJeddah.name = "Jeddah Hospital"
hospitalJeddah.hospitalColor = "Blue"
hospitalJeddah.idBilding = 7
hospitalJeddah.sayHai()


class AdministrativeSection : Hospital {
    var sectionName : String = ""
    var idSection : Double = 0
    var numOfEmbloyee : Float = 0
    
    func Admin(){
        print("This AdministrativeSection in \(name)")
    }
}
var admin = AdministrativeSection()
admin.name = "New York City"
admin.sectionName = "finincial Section"
admin.idSection = 2
admin.numOfEmbloyee = 5000
admin.Admin()


 class Financialmanangment : AdministrativeSection {
    var allSectionNum = [""]
    var allEmployee = [0:""]
    func info() {
        print("this section in \(name) and all employee name is \(allEmployee) all this employee work in \(allSectionNum) in id section \(idSection)")
    }
}

var section1 = Financialmanangment()
section1.name = "Farasan island"
section1.allSectionNum = ["Money Section","Employee Salary"]
section1.allEmployee = [1:"Abdulrazaq Ali",2:"Ali",3:"Khalid"]
section1.idSection = 7
section1.info()
print(section1.info())
var section2 = Financialmanangment()
section2.name = "Jazan Hospital"
section2.allSectionNum = ["Money Section","Employee Salary","Money Transfor"]
section2.allEmployee = [1:"Anas AL-hakmi",2:"Ali AL-Sharif",3:"Hasan AL-Abas",4:"Ayman AL-Amry"]
section2.idSection = 3
section2.info()
print(section2.info())

class HumanResourceManagement : AdministrativeSection {
        var embloyeeName:String = ""
        var birthday:String = ""
        var born : [String] = [""]
        var Salary : Int = 0
      
    override func sayHai() {
        print("Hi \(embloyeeName) you born in \(born) and your birthay \(birthday) you salary \(Salary)" )
    }
}

var employee1 = HumanResourceManagement()
employee1.embloyeeName = "Abdulrazaq"
employee1.birthday = "2001"
employee1.born = ["Farasan"]
employee1.Salary = 16000
employee1.sayHai()


class MarketingManagement : AdministrativeSection {
    var sections = [1:""]
    var jobTitle = [""]
    
    func Explain() {
        print("Hospital have more section on markiting and the famous \(sections) and the jop title was \(jobTitle) ")
    }
}

var markitingSection = MarketingManagement()
markitingSection.jobTitle = ["Tourism Marketing","nternational Marketing","Marketing Ethics"]
markitingSection.sections = [1:"social media marketing",2:"Product Markiting"]
markitingSection.Explain()


class HealthSction : Hospital {
    var HealthSectionNum : Double = 0
    var allEmployeeHealth : Int = 0
    
    func Health() {
        print("the health section in \(name) and all employee number was\(allEmployeeHealth) this Healthsection number \(HealthSectionNum)")
    }
}

var HealthsectionFarssan = HealthSction()
HealthsectionFarssan.name
HealthsectionFarssan.allEmployeeHealth = 350
HealthsectionFarssan.HealthSectionNum = 200
HealthsectionFarssan.Health()

class EmergencyPharmacy : HealthSction {
    var Medicationnumber : Float = 0
    var numOfmedicine : Int = 0

    func EmergencyPharmacyy(){
        print("the pharmacy in \(name) that was have a \(numOfmedicine) number of medacine and the health section number is \(HealthSectionNum)")
    }
}
var medacine = EmergencyPharmacy ()
HealthsectionFarssan.name
medacine.HealthSectionNum = 15
medacine.numOfmedicine = 1000
medacine.EmergencyPharmacyy()


class x_rayplace : HealthSction {
    var numOfXray : Int = 0
    var numofemployee : Int = 0
    func xray() {
        print("number of xray in one day \(numOfXray) and number of employee \(numofemployee)")
    }
}
var xray = x_rayplace()
xray.numOfXray = 200
xray.numofemployee = 600
xray.xray()



class Surgery : HealthSction {
    var nameOfsurgary : [String] = [" "]
    var salaryOfSurgary : Int = 0
    func makesurgary() {
        print("we have to surgary in our hospital \(nameOfsurgary) each them for \(salaryOfSurgary)")
    }
}
var surg = Surgery()
surg.nameOfsurgary = ["Abdominal surgery" , "Orthopaedic Surgery"]
surg.salaryOfSurgary = 180_000
surg.makesurgary()


class Childrensection : HealthSction {
    var numberofbeds : Int = 0
    var numOfDector : Int = 0
    func children() {
        print("we have \(numberofbeds) of beds and \(numOfDector) Doctor avilable")
    }
}
var children = Childrensection()
children.numOfDector = 30
children.numberofbeds = 10
children.children()


// finish 10 Hospital class 





 class Music  {
    var name : String = ""
    var musicalInstrument : String = ""
    func musicInfo() {
        print("The most popular music in the Middle East \(name) is very good and the machine use is\(musicalInstrument)")
    }
}
var music = Music()
music.name = " Arabic music"
music.musicalInstrument = " oud"
music.musicInfo()



class Symphony : Music {
    var numOfPlayer : Int = 60
    var numOfmachin : Int = 60
    func symphonyinfo() {
        print("The most popular music in the Europe is \(name) and people how work in it \(numOfPlayer) and all machine was \(numOfmachin)")
    }
}
var sympho = Symphony()
sympho.name = "Symphony"
sympho.numOfPlayer
sympho.numOfmachin
sympho.symphonyinfo()
private class trumpet : Symphony {
    var Datecreated : String = " 1500 BC"
    var color : String = "Goold"
}
fileprivate class Piano : Symphony {
    var Datecreated : String = " 1520 BC"
    var color : String = "Black"
}

class Orchestra : Music {
    var numOfPlayer : Int = 60
    var numOfmachin : Int = 60
    func orchestra1() {
        print("The most popular music in the Europe is \(name) and people how work in it \(numOfPlayer) and all machine was \(numOfmachin)")
    }
}
    var orcha = Orchestra()
    orcha.name = "Orchestra"
    orcha.numOfPlayer
    orcha.numOfmachin
    orcha.orchestra1()
   
    
class Also : Orchestra {
    var Datecreated : String = " 1556 BC"
    var color : String = "brown"
}


class Concerto : Music {
    var numOfPlayer : Int = 60
    var numOfmachin : Int = 60
    func concerto() {
        print("The most popular music in the Europe is \(name) and people how work in it \(numOfPlayer) and all machine was \(numOfmachin)")
    }
  
}
var concirto1 = Concerto()
concirto1.name = "Concirto"
concirto1.numOfPlayer
concirto1.numOfmachin
concirto1.concerto()
class Flute : Concerto {
    var Datecreated : String = " 1780 BC"
    var color : String = "gray"
}
class Jazz : Music {
    var numOfPlayer : Int = 1
    var numOfmachin : Int = 1
    func concerto() {
        print("The most popular music in the Amarica is \(name) and people how work in it \(numOfPlayer) and all machine was \(numOfmachin)")
    }
}
var jazz = Jazz()
jazz.name = "Concirto"
jazz.numOfPlayer
jazz.numOfmachin
jazz.concerto()

class Saxophone : Jazz {
    var Datecreated : String = " 1840 BC"
    var color : String = "goold"
}

// finish 10 class of music





 class Coffee {
    var coffeeName : String = ""
    var colorOfcup : String = ""
    
     func Coffee() {
         print("coffee name is \(coffeeName) and the color of cup is \(colorOfcup)")
     }
}

class HotCoffee : Coffee {
    var typeOfHotCoffee :[String] = [" "]
    var sizeOfHotCoffee = ["" : ""]
     func HotCoffee() {
        print("we have tow tybe of hot coffee \(typeOfHotCoffee) and what size do you want \(sizeOfHotCoffee)")
    }
    
    
}
var coff = HotCoffee()
coff.typeOfHotCoffee = ["Hot Coffee With Milk", "Hot Coffee With Out Milk"]
coff.sizeOfHotCoffee = ["espreesso" : "small", "latte" : "mideum"]
coff.HotCoffee()



class ColdCoffee : Coffee {
    var typeOfcoldCoffee :[String] = [" "]
    var sizeOfcoldCoffee = ["" : ""]
    func ColdCoffee() {
        print("we have tow tybe of hot coffee \(typeOfcoldCoffee) and what size do you want \(sizeOfcoldCoffee)")
    }
}
var coffC = ColdCoffee()
coffC.typeOfcoldCoffee = ["Cold Coffee With Milk", "Cold Coffee With Out Milk"]
coffC.sizeOfcoldCoffee = ["Amaricano Cold" : "mideum", "latte" : "midum"]

class V60 : Coffee {
    var minuteToBereadey : String = ""
}

class HotCoffeeWithMilk : HotCoffee {
    var mineuOfCoffeeWithMilk = ["latte","Spanish latte","Caramil latte"]
    var priceOfCoffeeWithMilk = ["latte" : 250, "Spanish latte": 450, "caramil latte":1000]
    func HotWithMilk() {
        print("this is the mineu \(mineuOfCoffeeWithMilk) and this is the price \(priceOfCoffeeWithMilk)")
    }
}
var coffWithMilk = HotCoffeeWithMilk()
coffWithMilk.mineuOfCoffeeWithMilk
coffWithMilk.priceOfCoffeeWithMilk
coffWithMilk.HotWithMilk()
class HotCoffeeWithOutMilk : HotCoffee {
    var mineuOfCoffeeWithOutMilk = ["Amrican coffee","black Coffee","espresso"]
    var priceOfCoffeeWithOutMilk = ["Amrican coffee" : 150, "black Coffee": 100, "espresso":2000]
    func HotWithOutMilk() {
        print("this is the mineu \(mineuOfCoffeeWithOutMilk) and this is the price \(priceOfCoffeeWithOutMilk)")
    }
}
var coffwithOutMilk = HotCoffeeWithOutMilk()
coffwithOutMilk.mineuOfCoffeeWithOutMilk
coffwithOutMilk.priceOfCoffeeWithOutMilk
coffwithOutMilk.HotWithOutMilk()

class ColdCoffeWithMilk : ColdCoffee {
    var mineuOfCoffeeColdWithMilk = ["latte","Spanish latte","Caramil latte"]
    var priceOfCoffeeColdWithMilk = ["latte" : 750, "Spanish latte": 3240, "caramil latte":90]
    
    func ColdCoffeWithMilk() {
        print("this is the mineu \(mineuOfCoffeeColdWithMilk) and this is the price \(priceOfCoffeeColdWithMilk)")
    }
}
var coffCold = ColdCoffeWithMilk()
coffCold.mineuOfCoffeeColdWithMilk
coffCold.priceOfCoffeeColdWithMilk
coffCold.ColdCoffeWithMilk()
class ColdCoffeWithOutMilk : ColdCoffee {
    var mineuOfCoffeeColdWithOutMilk = ["Amirican coffe","Black coffee",]
    var priceOfCoffeeColdWithOutMilk = ["Amirican" : 90, " Black coffee": 35]
    func coldCoffeWithOutMilk() {
        print("this is the mineu \(mineuOfCoffeeColdWithOutMilk) and this is the price \(priceOfCoffeeColdWithOutMilk)")
    }
    
}
var coldWithOutMilk = ColdCoffeWithOutMilk()
coldWithOutMilk.mineuOfCoffeeColdWithOutMilk
coldWithOutMilk.priceOfCoffeeColdWithOutMilk
coldWithOutMilk.coldCoffeWithOutMilk()
class HotV60 : V60 {
    var mineuOfHotV60 = ["V60 Hot"]
    var priceOfHotCoffee = ["V60 Hot" : 2000]
    func HotV60() {
        print("this is the mineu \(mineuOfHotV60) and this is the price \(priceOfHotCoffee)")
    }
}
var v60Hot = HotV60()
v60Hot.mineuOfHotV60
v60Hot.priceOfHotCoffee
v60Hot.HotV60()


class ColdV60 : V60 {
    var mineuOfColdV60 = ["V60 Cold"]
    var priceOfColdCoffee = ["V60 Cold" : 2800]
    func ColdV60() {
        print("this is the mineu \(mineuOfColdV60) and this is the price \(priceOfColdCoffee)")
    }
}
var v60Cold = ColdV60()
v60Cold.mineuOfColdV60
v60Cold.priceOfColdCoffee
v60Cold.ColdV60()

// finish 10 coffe class


// use protocol from swift in struct
struct Student : CustomStringConvertible {
    var description: String {
        return "Student \(studentname) very Smart he git \(studentnum)"
    }
    var studentname : String
    var studentnum : Int
    
}
var student1 = Student(studentname: "Abdulrazaq", studentnum: 100)
print(student1.description)



// i create my protocol
protocol PlayFootball {
    func play()
        
    
}

class Football : PlayFootball {
    func play() {
        print("are you play Soccer ⚽️ ")
    }
    
    
}
var playSoccer = Football()
playSoccer.play()
class Basktball : Football  {
    override func play() {
        print("are you play Basktball 🏀 ")
    }
}
var basktBall = Basktball()
basktBall.play()
class Golf : Football {
    override func play() {
        print("are you play Basktball 🏌🏻 ")
    }
}
var golf = Golf()
golf.play()

class Tenis : Football {
    override func play() {
        print("are you play Basktball 🎾 ")
    }
}
var tenis = Tenis()
tenis.play()



// use enum with Swith case
enum Days {
    case sunday,monday,thusday,wednsday,thursday,friday,sutrday
}
var workHour = Days.sunday
workHour = Days.monday
workHour = Days.thusday
workHour = Days.wednsday
workHour = Days.thusday
workHour = Days.friday
workHour = Days.sutrday
switch workHour {
    
case .sunday:
    print("From 8:00 AM TO 3:00 PM")
case .monday:
    print("From 10:00 AM TO 9:00 PM")
case .thusday:
    print("From 3:00 AM TO 4:00 AM")
case .wednsday:
    print("From 6:00 AM TO 12:00 PM")
case .thursday:
    print("From 7:00 AM TO 12:00 PM")
case .friday:
    print("From 4:00 AM TO 3:00 AM")
case .sutrday:
    print("From 8:00 AM TO 3:00 PM")
}





let SwiftKeyWoord = ["var","let","func","init","Struct","class","protocol","enum","associatedtype","deinit","extension","fileprivate","import","inout","internal","open","operator","private","public","rethrows","static","subscript","typealias","break","case","continue","default","defer","do","else","fallthrough","for","guard","if","in","repeat","return","switch","where","while","Any","as","catch","false","is","nil","super","self","throw","throws","true","try","_","#available"]
